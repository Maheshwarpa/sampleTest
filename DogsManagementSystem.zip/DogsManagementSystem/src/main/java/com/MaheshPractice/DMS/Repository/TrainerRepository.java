package com.MaheshPractice.DMS.Repository;

import org.springframework.data.repository.CrudRepository;

import com.MaheshPractice.DMS.Models.Trainer;

public interface TrainerRepository extends CrudRepository<Trainer, Integer> {

}